from load_data import *
intro2="Hey There! 👋 Welcome To The Link Styler Bot 🤖. My Name Is [Insert Bot Name Here], And I'm Here To Help You Make Your Links Pop 💥. Want To Give Your Channel A Fresh Look With Some Customized Links And Buttons?" 
setting="This Bot Is Easy To Understand😀 \n •) Set The Title For Your Message\n •Change Style Using ⚙️ \n •) Your Data Is Not Stored Anywhere So You Have To Set These Values Everytime To Use Me ♻️"
row_num="•Defaut is Set To 2 Buttons In Row \n •) Currently We Support Only 2 Buttons In Row,It Will Be Increased In Next Update \n •) HTML links Will Be Available In Next Update \n Join Channel To Receive New Updates 🌟"
links_txt="💡 You Can Send {} Any Photo With Links In Caption Or Any Text With Links \n Use /help To Access Help Section"
starting_message="👋 Hey There {}! \n 👉 I Can Convert Multiple Links Into Clickable Buttons 🌟 \n 👉 You Can Send Me Multiple Links And I Will Convert It Into Buttons For You 😊\n 👉 Click On Start Button To Begin" 
next_1="👉Click On Customize Links To Customize You Links 🔗 \n👉 For More Info You Can Go To Others  "
next_2="👉 Row Width : Number Of Buttons In Row \n👉 Title : Text In Message \n👉 Label : Label On Buttons-Premium"
next_78="👉Set Row Width \n👉 Default Is Set To 2 \n☛ 1,2,3 Are Available In Free Plann \n👉  Join Premium To Use Others \n☛ HTML Links Are Not Supported Yet "
next_3="🎉 Set Row Width 📏 \n👉 Default Is Set To 2 \n👉 1,2,3 Are Available In Free Plan \n👉 Join Premium To Use Others 💰 \n ❌ HTML Links Are Not Supported Yet 🚫"
next_4=" Set Title  📌 \n👉 Your Next Message Will Be Treated as a Title For Message 🔖 \n👉 Title Should Be In One Message 🚨"
next_5="Set Label🏷️ \n👉 Your Next Message Will Be Treated As A Label \n👉 label Must Be In One Message Only " 
about=f'╒═════════════════════✰°\n ➥ BOT NAME:- Link Styler Bot \n ➥ USERNAME :- @linkstylerbot \n ➥ LAUNCH DATE :- 14-2-2021 \n ➥ LAST UPDATED:-12-2-2003 °✰═════════════════════╛'
about="╭─────────────────────╮\n      ❝𝐋𝐈𝐍𝐊 𝐒𝐓𝐘𝐋𝐄𝐑 𝐁𝐎𝐓❞ \n      ➥ LAUNCH DATE :- 23-12-2003\n      ➥ LAST UPDATED :-12-12-2038 \n      ➥ DEVELOPER :- @devsavior\n      ➥ TOTAL USERS :- {}\n      ➥ <a href='https://t.me/BotsArchive/2721'>FEEDBACK</a> \n      ➥ LAUNCH DATE :- 2.0.0.1 \n╰─────────────────────╯"


next_6="\n👉 Unlock Premium Features and Enjoy The Best Of This Bot \n👉 VISIT FAQs For Better Understanding This Bot \n👉 For More Queries and Bugs Please Use Support Button \n👉 Thanks For Using This Bot"
rate="https://t.me/BotsArchive/2721" 
premium="Premium Version Is Just Launched To Keep This Bot Running!! \n👉 You Can Enjoy Premium Features at just 30rs per month (1rs/day) or get a discount at 100rs for 5 months (0.6rs/day) \n👉 Indian Users Can Pay With UPI and Rest Can Use Stripe Or Crypto \n👉 "
crypto="BTC:<code> bc1q8s8pq8880659rsufmnfmqpcdh554qag5xcvhya</code> \n👉 ETH:<code>0x750C9976c988BE7E233EF6c2579e8d0C22F84019</code> \n👉 DOGECOIN :<code>DQPL7SrAJVWxALufeBsLvKbYmEngrzzJcQ</code> \n👉 Please Pay Either For 1 month Or 5 Months "
devcom="Available Commands \n /add_pro Add User In Premium Members \n /add_channel Adds Channel In Premium \n /get_users get total users \n /post Post To Users \n Total User:Not Defined \n "
upi_text="UPI:<code>devsavior@axl</code> \n Either Pay For One Month Or 5 Month \n After Payment Is Done Send Screenshot "
