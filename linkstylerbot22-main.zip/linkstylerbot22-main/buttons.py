from telebot.types import InlineKeyboardButton, InlineKeyboardMarkup 
def gen_markup():
  buttons = [[InlineKeyboardButton('Featured Channel ®️', url='https://t.me/DevSavior')],
             [InlineKeyboardButton('Lets Start ▶️', callback_data='start')]]
  m = InlineKeyboardMarkup(buttons)
  return m
def gen_markup2():
  buttons = [InlineKeyboardButton('Customize Links', callback_data='customize')],[
InlineKeyboardButton('Others',callback_data='others')],[InlineKeyboardButton('Featured Channel',url='t.me/devsavior'),InlineKeyboardButton ('◀️',callback_data='back1')]
  m = InlineKeyboardMarkup(buttons)
  return m
def gen_markup31():
  buttons = [[InlineKeyboardButton('HTML Links🔜', callback_data='01')],
             [
               InlineKeyboardButton('1 In Row', callback_data='11'),
               InlineKeyboardButton('2 In Row', callback_data='21')
             ],
             [
               InlineKeyboardButton('3 In Row', callback_data='31'),
               InlineKeyboardButton('4 In Row🔒', callback_data='41')
             ],[InlineKeyboardButton('5 In Row🔒', callback_data="51")]
            ,[InlineKeyboardButton ('◀️',callback_data='back31')]]
  m = InlineKeyboardMarkup(buttons)
  return m
def gen_markup41():
  buttons = [[InlineKeyboardButton('HTML Links🔜', callback_data='01')],
             [
               InlineKeyboardButton('1 In Row✅', callback_data='11'),
               InlineKeyboardButton('2 In Row', callback_data='21')
             ],[
               InlineKeyboardButton('3 In Row', callback_data='31'),
               InlineKeyboardButton('4 In Row🔒', callback_data='41')
             ],[InlineKeyboardButton('5 In Row🔒',callback_data='51')], [InlineKeyboardButton('◀️', callback_data='back31')]
            ]
  m = InlineKeyboardMarkup(buttons)
  return m
def gen_markup51():
  buttons = [[InlineKeyboardButton('HTML Links🔜', callback_data='01')],
             [
               InlineKeyboardButton('1 In Row', callback_data='11'),
               InlineKeyboardButton('2 In Row✅', callback_data='21')
             ], [
               InlineKeyboardButton('3 In Row', callback_data='31'),
               InlineKeyboardButton('4 In Row🔒', callback_data='41')
             ],[InlineKeyboardButton('5 In Row🔒',callback_data='51')], [InlineKeyboardButton('◀️', callback_data='back31')]]
  m = InlineKeyboardMarkup(buttons)
  return m
def gen_markup61():
  buttons = [[InlineKeyboardButton('HTML Links🔜', callback_data='01')],
             [
               InlineKeyboardButton('1 In Row', callback_data='11'),
               InlineKeyboardButton('2 In Row', callback_data='21')
             ], [
               InlineKeyboardButton('3 In Row✅', callback_data='31'),
               InlineKeyboardButton('4 In Row🔒', callback_data='41')
             ],[InlineKeyboardButton('5 In Row🔒',callback_data='51')], [InlineKeyboardButton('◀️', callback_data='back31')]]
  m = InlineKeyboardMarkup(buttons)
  return m
def gen_markup71():
  buttons = [[InlineKeyboardButton('HTML Links🔜', callback_data='01')],
             [
               InlineKeyboardButton('1 In Row', callback_data='11'),
               InlineKeyboardButton('2 In Row', callback_data='21')
             ], [
               InlineKeyboardButton('3 In Row', callback_data='31'),
               InlineKeyboardButton('4 In Row🔒', callback_data='41')
             ],[InlineKeyboardButton('5 In Row🔒',callback_data='51')], [InlineKeyboardButton('◀️', callback_data='back31')]]
  m = InlineKeyboardMarkup(buttons)
  return m 
def gen_markup81():
  buttons = [[InlineKeyboardButton('HTML Links🔜', callback_data='01')],
             [
               InlineKeyboardButton('1 In Row', callback_data='11'),
               InlineKeyboardButton('2 In Row', callback_data='21')
             ], [
               InlineKeyboardButton('3 In Row', callback_data='31'),
               InlineKeyboardButton('4 In Row🔒', callback_data='41')
             ],[InlineKeyboardButton('5 In Row🔒',callback_data='51')], [InlineKeyboardButton('◀️', callback_data='back31')]]
  m = InlineKeyboardMarkup(buttons)
  return m
def gen_markup101():
  buttons = [InlineKeyboardButton('Set Row Width', callback_data='setting1'),
InlineKeyboardButton('Set Title ✍️',callback_data='title1')],            [InlineKeyboardButton('Set Label🔒', callback_data='text1')],[InlineKeyboardButton ('◀️',callback_data='back61')]
  m = InlineKeyboardMarkup(buttons)
  return m 
def gen_markup111():
  buttons = [InlineKeyboardButton('About', callback_data='about1'),            InlineKeyboardButton('Premium💰 ', callback_data='premium')],[InlineKeyboardButton("Dev Options",callback_data='dev'),InlineKeyboardButton ('◀️',callback_data='back61')]
  m = InlineKeyboardMarkup(buttons)
  return m 
def gen_markup121():
  buttons = [[InlineKeyboardButton('◀️', callback_data='back31')]]
  m = InlineKeyboardMarkup(buttons)
  return m 
def gen_markup131():
  buttons = [[InlineKeyboardButton('◀️', callback_data='back41')]]
  m = InlineKeyboardMarkup(buttons)
  return m 
def gen_markup14h1():
  buttons = [InlineKeyboardButton('UPI',callback_data="upi")],[
InlineKeyboardButton('Stripe',url='www.stripe.pay.com')],[InlineKeyboardButton('Featured Channel',url='t.me/devsavior'),InlineKeyboardButton ('◀️',callback_data='back71')]
  m = InlineKeyboardMarkup(buttons) 
  return m 

def gen_markup3():
  buttons = [[InlineKeyboardButton('HTML Links🔜', callback_data='0')],
             [
               InlineKeyboardButton('1 In Row', callback_data='1'),
               InlineKeyboardButton('2 In Row', callback_data='2')
             ],
             [
               InlineKeyboardButton('3 In Row', callback_data='3'),
               InlineKeyboardButton('4 In Row', callback_data='4')
             ],[InlineKeyboardButton('5 In Row', callback_data="5")]
            ,[InlineKeyboardButton ('◀️',callback_data='back3')]]
  m = InlineKeyboardMarkup(buttons)
  return m
def gen_markup4():
  buttons = [[InlineKeyboardButton('HTML Links🔜', callback_data='0')],
             [
               InlineKeyboardButton('1 In Row✅', callback_data='1'),
               InlineKeyboardButton('2 In Row', callback_data='2')
             ],[
               InlineKeyboardButton('3 In Row', callback_data='3'),
               InlineKeyboardButton('4 In Row', callback_data='4')
             ],[InlineKeyboardButton('5 In Row',callback_data='5')], [InlineKeyboardButton('◀️', callback_data='back3')]
            ]
  m = InlineKeyboardMarkup(buttons)
  return m
def gen_markup5():
  buttons = [[InlineKeyboardButton('HTML Links🔜', callback_data='0')],
             [
               InlineKeyboardButton('1 In Row', callback_data='1'),
               InlineKeyboardButton('2 In Row✅', callback_data='2')
             ], [
               InlineKeyboardButton('3 In Row', callback_data='3'),
               InlineKeyboardButton('4 In Row', callback_data='4')
             ],[InlineKeyboardButton('5 In Row',callback_data='5')], [InlineKeyboardButton('◀️', callback_data='back3')]]
  m = InlineKeyboardMarkup(buttons)
  return m
def gen_markup6():
  buttons = [[InlineKeyboardButton('HTML Links🔜', callback_data='0')],
             [
               InlineKeyboardButton('1 In Row', callback_data='1'),
               InlineKeyboardButton('2 In Row', callback_data='2')
             ], [
               InlineKeyboardButton('3 In Row✅', callback_data='3'),
               InlineKeyboardButton('4 In Row', callback_data='4')
             ],[InlineKeyboardButton('5 In Row',callback_data='5')], [InlineKeyboardButton('◀️', callback_data='back3')]]
  m = InlineKeyboardMarkup(buttons)
  return m
def gen_markup7():
  buttons = [[InlineKeyboardButton('HTML Links🔜', callback_data='0')],
             [
               InlineKeyboardButton('1 In Row', callback_data='1'),
               InlineKeyboardButton('2 In Row', callback_data='2')
             ], [
               InlineKeyboardButton('3 In Row', callback_data='3'),
               InlineKeyboardButton('4 In Row✅', callback_data='4')
             ],[InlineKeyboardButton('5 In Row',callback_data='5')], [InlineKeyboardButton('◀️', callback_data='back3')]]
  m = InlineKeyboardMarkup(buttons)
  return m 
def gen_markup8():
  buttons = [[InlineKeyboardButton('HTML Links🔜', callback_data='0')],
             [
               InlineKeyboardButton('1 In Row', callback_data='1'),
               InlineKeyboardButton('2 In Row', callback_data='2')
             ], [
               InlineKeyboardButton('3 In Row', callback_data='3'),
               InlineKeyboardButton('4 In Row', callback_data='4')
             ],[InlineKeyboardButton('5 In Row✅',callback_data='5')], [InlineKeyboardButton('◀️', callback_data='back3')]]
  m = InlineKeyboardMarkup(buttons)
  return m
def gen_markup10():
  buttons = [InlineKeyboardButton('Set Row Width', callback_data='setting'),
InlineKeyboardButton('Set Title ✍️',callback_data='title')],            [InlineKeyboardButton('Set Label ', callback_data='text')],[InlineKeyboardButton ('◀️',callback_data='back2')]
  m = InlineKeyboardMarkup(buttons)
  return m 
def gen_markup11():
  buttons = [InlineKeyboardButton('About', callback_data='about'),            InlineKeyboardButton('Account', callback_data='account')],[InlineKeyboardButton("Devb Options",callback_data='dev'),InlineKeyboardButton ('◀️',callback_data='back31_pro')]
  m = InlineKeyboardMarkup(buttons)
  return m 
def gen_markup12():
  buttons = [[InlineKeyboardButton('◀️', callback_data='back3')]]
  m = InlineKeyboardMarkup(buttons)
  return m 
def gen_markup13():
  buttons = [[InlineKeyboardButton('◀️', callback_data='back4')]]
  m = InlineKeyboardMarkup(buttons)
  return m 
def gen_markup141():
  buttons = [InlineKeyboardButton('UPI',callback_data="upi")],[InlineKeyboardButton('Crypto',callback_data='crypto')
,InlineKeyboardButton('Stripe',url='www.stripe.pay.com')],[InlineKeyboardButton('Featured Channel',url='t.me/devsavior'),InlineKeyboardButton ('◀️',callback_data='back71')]
  m = InlineKeyboardMarkup(buttons) 
  return m 
def accordec():
  buttons = [InlineKeyboardButton("Accept",callback_data="accept")],[
InlineKeyboardButton('Decline',callback_data="decline")]
  m = InlineKeyboardMarkup(buttons) 
  return m
def gen_markup21():
  buttons = [InlineKeyboardButton('Customize Links', callback_data='customize1')],[
InlineKeyboardButton('Others',callback_data='others1')],[InlineKeyboardButton('Featured Channel',url='t.me/devsavior'),InlineKeyboardButton ('◀️',callback_data='back21')]
  m = InlineKeyboardMarkup(buttons)
  return m
def gen_markup118():
  buttons = [[InlineKeyboardButton('Cancel Payment', callback_data='cancel')]]
  m = InlineKeyboardMarkup(buttons)
  return m  
def gen_markup119():
  buttons = [[InlineKeyboardButton('Cancel Payment', callback_data="Cancel"),InlineKeyboardButton('Send Proof',callback_data='proof')]]
  m = InlineKeyboardMarkup(buttons)
  return m  
def gen_markup129():
  buttons = [[InlineKeyboardButton('Cancel Payment', callback_data="Cancel1"),InlineKeyboardButton('Send Proof',callback_data='proof')]]
  m = InlineKeyboardMarkup(buttons)
  return m  
